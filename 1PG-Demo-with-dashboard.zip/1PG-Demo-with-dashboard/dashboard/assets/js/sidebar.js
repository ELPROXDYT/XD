$('.hamburger').on('click', function() {
  $('#sidebarExtension').toggleClass('closed');
});